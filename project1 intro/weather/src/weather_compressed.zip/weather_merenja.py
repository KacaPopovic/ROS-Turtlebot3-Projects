#!/usr/bin/env python3

import rospy
from rospy.numpy_msg import numpy_msg
from std_msgs.msg import String
import csv
from rospy_tutorials.msg import Floats
import numpy


def talker_merenja():
    #Inicialisation of publisher who reads csv file
    pub= rospy.Publisher('weather_csv', numpy_msg(Floats), queue_size=10)
    rospy.init_node('weather_merenja', anonymous=False)
    r=rospy.Rate(10)
    file_path="/home/katarina/catkin_ws/src/weather/src/data.csv"


    with open(file_path, 'r') as csv_file:
        csv_reader=csv.reader(csv_file, delimiter=',')
        br=0
        for row in csv_reader:

            #skipping the row titles and extracting needed data
            if br>0:
                date=row[0]
                date_array=date.split("-")
                day=int(date_array[0])
                month=int(date_array[1])
                max= int(row[1])
                min=int(row[2])
                average=float(row[3])
                a=numpy.array([day, month, max, min, average], dtype=numpy.float32)
                row=row[:4]
                if month<8:
                    #only seding info for first 7 months
                    rospy.loginfo("Row: {}".format(a))
                    pub.publish(a)
                else:
                    break
            else:
                pass
            br=br+1
            r.sleep()
if __name__== '__main__':
    try:
        talker_merenja()
    except rospy.ROSInterruptException:
        pass

